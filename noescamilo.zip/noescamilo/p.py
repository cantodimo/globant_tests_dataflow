class OffsetRange(object):

  def __init__(self, start, stop):
    self.start = start
    self.stop = stop


o = OffsetRange(1,2)
print(o.start)
print(o.stop)

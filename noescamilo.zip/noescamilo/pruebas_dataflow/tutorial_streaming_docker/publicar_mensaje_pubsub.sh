gcloud pubsub topics publish messages_dataflow_streaming_docker --message='{"url": "https://cloud.google.com/bigquery/", "review": "positive"}'
